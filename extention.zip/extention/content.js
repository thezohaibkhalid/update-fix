(function () {
  "use strict";

  class ChatGPTEnhancer {
    constructor() {
      this.sidebar = null;
      this.arrowToggle = null;
      this.isOpen = false;
      this.currentTab = "questions";
      this.questions = [];
      this.pinnedQuestions = new Set();
      this.folders = [];
      this.availableChats = [];
      this.observers = [];
      this.searchQuery = "";
      this.isInitialized = false;
      this.scanTimeout = null;
      this.currentTheme = "dark";

      this.availableTags = [
        { id: "work", name: "Work", color: "work" },
        { id: "personal", name: "Personal", color: "personal" },
        { id: "research", name: "Research", color: "research" },
        { id: "coding", name: "Coding", color: "coding" },
        { id: "creative", name: "Creative", color: "creative" },
        { id: "learning", name: "Learning", color: "learning" },
        { id: "business", name: "Business", color: "business" },
        { id: "other", name: "Other", color: "other" },
      ];

      this.init();
      window.chatGPTEnhancer = this;
    }

    init() {
      try {
        console.log("🗺️ ChatGPT ChatMapper: Initializing...");

        if (document.readyState === "loading") {
          document.addEventListener("DOMContentLoaded", () =>
            this.initializeExtension()
          );
        } else {
          this.initializeExtension();
        }
      } catch (error) {
        console.error("❌ ChatGPT ChatMapper: Initialization error:", error);
      }
    }

    initializeExtension() {
      try {
        this.loadFromStorage();
        this.createArrowToggle();
        this.createSidebar();
        this.initializeTheme();
        this.setupObservers();

        setTimeout(() => {
          this.scanForQuestions();
          this.scanForAvailableChats();
        }, 3000);

        this.isInitialized = true;
        console.log("✅ ChatGPT ChatMapper: Initialized successfully");
      } catch (error) {
        console.error(
          "❌ ChatGPT ChatMapper: Extension initialization error:",
          error
        );
      }
    }

    validateTag(tagId) {
      if (!tagId) {
        console.error("❌ Tag ID is null or undefined");
        return null;
      }

      const tag = this.availableTags.find((t) => t && t.id === tagId);
      if (!tag) {
        console.error("❌ Tag not found for ID:", tagId);
        return null;
      }

      if (!tag.color || !tag.name) {
        console.error("❌ Invalid tag structure:", tag);
        return null;
      }

      return tag;
    }

    validateFolderName(name) {
      if (!name || typeof name !== "string") {
        return { valid: false, error: "Folder name is required" };
      }

      const trimmedName = name.trim();
      if (trimmedName.length === 0) {
        return { valid: false, error: "Folder name cannot be empty" };
      }

      if (trimmedName.length > 50) {
        return {
          valid: false,
          error: "Folder name must be less than 50 characters",
        };
      }

      const isDuplicate = this.folders.some(
        (folder) =>
          folder &&
          folder.name &&
          folder.name.toLowerCase() === trimmedName.toLowerCase()
      );

      if (isDuplicate) {
        return {
          valid: false,
          error: "A folder with this name already exists",
        };
      }

      return { valid: true, name: trimmedName };
    }

    createArrowToggle() {
      try {
        const existingToggle = document.querySelector(".cge-arrow-toggle");
        if (existingToggle) {
          existingToggle.remove();
        }

        this.arrowToggle = document.createElement("button");
        this.arrowToggle.className = "cge-arrow-toggle";
        this.arrowToggle.innerHTML = "◀";
        this.arrowToggle.title = "Toggle ChatMapper - Bitbuilder Productions";
        this.arrowToggle.addEventListener("click", (e) => {
          e.stopPropagation();
          this.toggleSidebar();
        });
        document.body.appendChild(this.arrowToggle);
        console.log("✅ Arrow toggle created");
      } catch (error) {
        console.error("❌ Error creating arrow toggle:", error);
      }
    }

    createSidebar() {
      try {
        const existingSidebar = document.querySelector(
          ".chatgpt-enhanced-sidebar"
        );
        if (existingSidebar) {
          existingSidebar.remove();
        }

        this.sidebar = document.createElement("div");
        this.sidebar.className = "chatgpt-enhanced-sidebar";
        this.sidebar.innerHTML = `
          

            <div class="cge-pinned-section" id="cge-pinned-section">
              <div class="cge-pinned-header">
                <span class="cge-pinned-title">📌 Pinned Questions</span>
                <span class="cge-pinned-count" id="cge-pinned-count">0</span>
              </div>
              <div class="cge-pinned-list" id="cge-pinned-list">
                <div class="cge-no-pins">No pinned questions yet</div>
              </div>
            </div>

            
          </div>
          <div class="cge-sidebar-content">
            <div class="cge-search-container" id="cge-search-container" style="display: none;">
              <input type="text" class="cge-search-input" id="cge-search-input" placeholder="Search...">
            </div>
            
            <div class="cge-tab-content active" id="cge-questions-tab">
              <div class="cge-section-header">
                <span>Questions in this chat</span>
                <span class="cge-question-count" id="cge-question-count">0</span>
              </div>
              <div class="cge-chat-list" id="cge-questions-list">
                <div class="cge-empty-state">🔍 Scanning for questions...</div>
              </div>
            </div>
            
            <!-- Chats Tab -->
            <div class="cge-tab-content" id="cge-chats-tab">
              <div class="cge-section-header">
                <span>Chat Folders</span>
                <span class="cge-folder-count" id="cge-folder-count">0</span>
              </div>
              <button class="cge-add-folder-btn" id="cge-add-folder">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="16" height="16">
                  <line x1="12" y1="5" x2="12" y2="19"/>
                  <line x1="5" y1="12" x2="19" y2="12"/>
                </svg>
                Create New Folder
              </button>
              <div class="cge-chat-list" id="cge-folders-list">
                <div class="cge-empty-state">📁 No folders yet. Create your first folder to organize chats!</div>
              </div>
            </div>
          </div>
          <div class="cge-sidebar-header">
            
            
          <div class="cge-tab-nav">
              <button class="cge-tab-btn active" data-tab="questions">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="16" height="16">
                  <circle cx="12" cy="12" r="10"/>
                  <path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"/>
                  <path d="M12 17h.01"/>
                </svg>
                Questions
              </button>
              <button class="cge-tab-btn" data-tab="chats">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="16" height="16">
                  <path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"/>
                </svg>
                Folders
              </button>
            </div>
            
            <div class="cge-header-actions">
              <button class="cge-header-button" id="cge-theme-btn">
                <span class="cge-theme-icon">☀️</span>
                <span class="cge-theme-text">Light</span>
              </button>
              <button class="cge-header-button" id="cge-search-btn">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                  <circle cx="11" cy="11" r="8"/>
                  <path d="m21 21-4.35-4.35"/>
                </svg>
                <span>Search</span>
              </button>
              <button class="cge-header-button" id="cge-export-btn">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                  <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/>
                  <polyline points="14,2 14,8 20,8"/>
                  <line x1="16" y1="13" x2="8" y2="13"/>
                  <line x1="16" y1="17" x2="8" y2="17"/>
                  <line x1="10" y1="9" x2="8" y2="9"/>
                </svg>
                <span>Notes</span>
              </button>
            </div>
            <div class="cge-branding">
              <div class="cge-branding-content">
                <div class="cge-branding-title">🗺️ Bitbuilder Productions</div>
                <div class="cge-branding-subtitle">ChatGPT ChatMapper</div>
              </div>
              <div class="cge-theme-indicator" id="cge-theme-indicator">🌙</div>
          </div>
        `;

        document.body.appendChild(this.sidebar);
        this.setupEventListeners();

        if (this.isOpen) {
          this.sidebar.classList.add("cge-open");
          this.arrowToggle?.classList.add("open");
          if (this.arrowToggle) this.arrowToggle.innerHTML = "▶";
        }

        console.log("✅ Sidebar created");
      } catch (error) {
        console.error("❌ Error creating sidebar:", error);
      }
    }

    setupEventListeners() {
      try {
        if (!this.sidebar) {
          console.error("❌ Sidebar not available for event listeners");
          return;
        }

        // Tab navigation
        const tabBtns = this.sidebar.querySelectorAll(".cge-tab-btn");
        tabBtns.forEach((btn) => {
          const tabBtn = btn;
          if (tabBtn && tabBtn.dataset && tabBtn.dataset.tab) {
            tabBtn.addEventListener("click", (e) => {
              e.stopPropagation();
              this.switchTab(tabBtn.dataset.tab);
            });
          }
        });

        // Search button
        const searchBtn = this.sidebar.querySelector("#cge-search-btn");
        if (searchBtn) {
          searchBtn.addEventListener("click", (e) => {
            e.stopPropagation();
            this.toggleSearch();
          });
        }

        // Export button
        const exportBtn = this.sidebar.querySelector("#cge-export-btn");
        if (exportBtn) {
          exportBtn.addEventListener("click", (e) => {
            e.stopPropagation();
            this.exportFullChatToPDF();
          });
        }

        // Add folder button
        const addFolderBtn = this.sidebar.querySelector("#cge-add-folder");
        if (addFolderBtn) {
          addFolderBtn.addEventListener("click", (e) => {
            e.stopPropagation();
            this.showTagSelectionModal();
          });
        }

        // Search input
        const searchInput = this.sidebar.querySelector("#cge-search-input");
        if (searchInput) {
          searchInput.addEventListener("input", (e) => {
            const target = e.target;
            this.searchQuery = target.value.toLowerCase();
            this.filterCurrentTab();
          });

          searchInput.addEventListener("keydown", (e) => {
            if (e.key === "Escape") {
              this.clearSearch();
            }
          });
        }

        // Theme toggle button
        const themeBtn = this.sidebar.querySelector("#cge-theme-btn");
        if (themeBtn) {
          themeBtn.addEventListener("click", (e) => {
            e.stopPropagation();
            this.toggleTheme();
          });
        }

        console.log("✅ Event listeners setup complete");
      } catch (error) {
        console.error("❌ Error setting up event listeners:", error);
      }
    }

    togglePinSection() {
      try {
        const pinSection = this.sidebar?.querySelector("#cge-pin-section");
        const pinToggleBtn = this.sidebar?.querySelector("#cge-pin-toggle-btn");

        if (!pinSection || !pinToggleBtn) return;

        if (pinSection.style.display === "none") {
          pinSection.style.display = "block";
          pinToggleBtn.classList.add("active");
        } else {
          pinSection.style.display = "none";
          pinToggleBtn.classList.remove("active");
        }
      } catch (error) {
        console.error("❌ Error toggling pin section:", error);
      }
    }

    toggleTheme() {
      try {
        this.currentTheme = this.currentTheme === "dark" ? "light" : "dark";
        document.body.setAttribute("data-cge-theme", this.currentTheme);

        const themeBtn = this.sidebar?.querySelector("#cge-theme-btn");
        const themeIndicator = this.sidebar?.querySelector(
          "#cge-theme-indicator"
        );

        if (themeBtn) {
          const icon = themeBtn.querySelector(".cge-theme-icon");
          const text = themeBtn.querySelector(".cge-theme-text");
          if (icon && text) {
            if (this.currentTheme === "light") {
              icon.textContent = "🌙";
              text.textContent = "Dark";
              if (themeIndicator) themeIndicator.textContent = "☀️";
            } else {
              icon.textContent = "☀️";
              text.textContent = "Light";
              if (themeIndicator) themeIndicator.textContent = "🌙";
            }
          }
        }

        this.saveToStorage();
        this.showSuccessMessage(`Switched to ${this.currentTheme} mode!`);
        console.log("✅ Theme toggled to:", this.currentTheme);
      } catch (error) {
        console.error("❌ Error toggling theme:", error);
      }
    }

    initializeTheme() {
      try {
        document.body.setAttribute("data-cge-theme", this.currentTheme);

        const themeBtn = this.sidebar?.querySelector("#cge-theme-btn");
        const themeIndicator = this.sidebar?.querySelector(
          "#cge-theme-indicator"
        );

        if (themeBtn) {
          const icon = themeBtn.querySelector(".cge-theme-icon");
          const text = themeBtn.querySelector(".cge-theme-text");
          if (icon && text) {
            if (this.currentTheme === "light") {
              icon.textContent = "🌙";
              text.textContent = "Dark";
              if (themeIndicator) themeIndicator.textContent = "☀️";
            } else {
              icon.textContent = "☀️";
              text.textContent = "Light";
              if (themeIndicator) themeIndicator.textContent = "🌙";
            }
          }
        }

        console.log("✅ Theme initialized:", this.currentTheme);
      } catch (error) {
        console.error("❌ Error initializing theme:", error);
      }
    }

    switchTab(tab) {
      try {
        if (!tab || !this.sidebar) return;

        this.currentTab = tab;

        const tabBtns = this.sidebar.querySelectorAll(".cge-tab-btn");
        tabBtns.forEach((btn) => {
          const tabBtn = btn;
          if (tabBtn.dataset.tab === tab) {
            tabBtn.classList.add("active");
          } else {
            tabBtn.classList.remove("active");
          }
        });

        const tabContents = this.sidebar.querySelectorAll(".cge-tab-content");
        tabContents.forEach((content) => {
          if (content.id === `cge-${tab}-tab`) {
            content.classList.add("active");
          } else {
            content.classList.remove("active");
          }
        });

        const searchInput = this.sidebar.querySelector("#cge-search-input");
        if (searchInput) {
          searchInput.placeholder =
            tab === "questions" ? "Search questions..." : "Search folders...";
        }

        if (tab === "questions") {
          this.renderQuestions();
        } else {
          this.renderFolders();
        }

        this.saveToStorage();
        console.log("✅ Switched to tab:", tab);
      } catch (error) {
        console.error("❌ Error switching tab:", error);
      }
    }

    toggleSidebar() {
      try {
        this.isOpen = !this.isOpen;

        if (this.isOpen) {
          this.sidebar?.classList.add("cge-open");
          this.arrowToggle?.classList.add("open");
          if (this.arrowToggle) {
            this.arrowToggle.innerHTML = "▶";
            this.arrowToggle.title = "Close ChatMapper";
          }
          this.scanForQuestions();
          this.scanForAvailableChats();
        } else {
          this.sidebar?.classList.remove("cge-open");
          this.arrowToggle?.classList.remove("open");
          if (this.arrowToggle) {
            this.arrowToggle.innerHTML = "◀";
            this.arrowToggle.title = "Open ChatMapper";
          }
          this.clearSearch();
        }

        this.saveToStorage();
        console.log("✅ Sidebar toggled:", this.isOpen ? "open" : "closed");
      } catch (error) {
        console.error("❌ Error toggling sidebar:", error);
      }
    }

    toggleSearch() {
      try {
        const searchContainer = this.sidebar?.querySelector(
          "#cge-search-container"
        );
        const searchInput = this.sidebar?.querySelector("#cge-search-input");
        const searchBtn = this.sidebar?.querySelector("#cge-search-btn");

        if (!searchContainer || !searchInput || !searchBtn) return;

        if (searchContainer.style.display === "none") {
          searchContainer.style.display = "block";
          searchInput.focus();
          searchBtn.classList.add("active");
        } else {
          this.clearSearch();
        }
      } catch (error) {
        console.error("❌ Error toggling search:", error);
      }
    }

    clearSearch() {
      try {
        const searchContainer = this.sidebar?.querySelector(
          "#cge-search-container"
        );
        const searchInput = this.sidebar?.querySelector("#cge-search-input");
        const searchBtn = this.sidebar?.querySelector("#cge-search-btn");

        if (searchContainer) searchContainer.style.display = "none";
        if (searchInput) searchInput.value = "";
        if (searchBtn) searchBtn.classList.remove("active");

        this.searchQuery = "";
        this.filterCurrentTab();
      } catch (error) {
        console.error("❌ Error clearing search:", error);
      }
    }

    filterCurrentTab() {
      try {
        if (this.currentTab === "questions") {
          this.filterQuestions();
        } else {
          this.filterFolders();
        }
      } catch (error) {
        console.error("❌ Error filtering current tab:", error);
      }
    }

    filterQuestions() {
      try {
        const questionItems = this.sidebar?.querySelectorAll(
          "#cge-questions-list .cge-question-item"
        );
        let visibleCount = 0;

        // Get current chat ID and create ordered questions list (pinned first)
        const currentChatId = this.getCurrentChatId();
        const pinnedQuestions = [];
        const unpinnedQuestions = [];

        this.questions.forEach((question) => {
          const pinKey = `${currentChatId}-${question.id}`;
          const isPinned = this.pinnedQuestions.has(pinKey);

          if (isPinned) {
            pinnedQuestions.push(question);
          } else {
            unpinnedQuestions.push(question);
          }
        });

        const orderedQuestions = [...pinnedQuestions, ...unpinnedQuestions];

        questionItems?.forEach((item, index) => {
          const question = orderedQuestions[index];
          if (!question) return;

          const matchesSearch =
            this.searchQuery === "" ||
            question.fullText.toLowerCase().includes(this.searchQuery) ||
            question.text.toLowerCase().includes(this.searchQuery);

          if (matchesSearch) {
            item.classList.remove("hidden");
            visibleCount++;
          } else {
            item.classList.add("hidden");
          }
        });

        this.showNoResultsMessage("questions", visibleCount);
      } catch (error) {
        console.error("❌ Error filtering questions:", error);
      }
    }

    filterFolders() {
      try {
        const folderItems = this.sidebar?.querySelectorAll(
          "#cge-folders-list .cge-folder-item"
        );
        let visibleCount = 0;

        folderItems?.forEach((item, index) => {
          const folder = this.folders[index];
          if (!folder) return;

          const matchesSearch =
            this.searchQuery === "" ||
            folder.name.toLowerCase().includes(this.searchQuery);

          if (matchesSearch) {
            item.classList.remove("hidden");
            visibleCount++;
          } else {
            item.classList.add("hidden");
          }
        });

        this.showNoResultsMessage("folders", visibleCount);
      } catch (error) {
        console.error("❌ Error filtering folders:", error);
      }
    }

    showNoResultsMessage(type, visibleCount) {
      try {
        const listId =
          type === "questions" ? "#cge-questions-list" : "#cge-folders-list";
        const list = this.sidebar?.querySelector(listId);
        if (!list) return;

        const existingNoResults = list.querySelector(".cge-no-results");

        if (this.searchQuery && visibleCount === 0) {
          if (!existingNoResults) {
            const noResults = document.createElement("div");
            noResults.className = "cge-no-results";
            noResults.textContent = `No ${type} found for "${this.searchQuery}"`;
            list.appendChild(noResults);
          }
        } else if (existingNoResults) {
          existingNoResults.remove();
        }
      } catch (error) {
        console.error("❌ Error showing no results message:", error);
      }
    }

    renderPinnedQuestions() {
      try {
        const pinnedList = this.sidebar?.querySelector("#cge-pinned-list");
        const pinCount = this.sidebar?.querySelector("#cge-pinned-count");
        const pinnedSection = this.sidebar?.querySelector(
          "#cge-pinned-section"
        );

        if (!pinnedList || !pinCount || !pinnedSection) return;

        const currentChatId = this.getCurrentChatId();
        const pinnedQuestions = this.questions.filter((q) => {
          const pinKey = `${currentChatId}-${q.id}`;
          return this.pinnedQuestions.has(pinKey);
        });

        pinCount.textContent = pinnedQuestions.length.toString();

        // Show/hide the entire pinned section based on whether there are pinned questions
        if (pinnedQuestions.length === 0) {
          pinnedSection.style.display = "none";
          return;
        } else {
          pinnedSection.style.display = "block";
        }

        pinnedList.innerHTML = pinnedQuestions
          .map(
            (question, index) => `
            <div class="cge-pinned-item" data-question-id="${
              question.id
            }" title="${this.escapeHtml(question.fullText)}">
              <span class="cge-pinned-number">${
                this.questions.findIndex((q) => q.id === question.id) + 1
              }</span>
              <span class="cge-pinned-text">${this.escapeHtml(
                question.text
              )}</span>
              <button class="cge-unpin-btn" data-question-id="${
                question.id
              }" title="Unpin question">✕</button>
            </div>
          `
          )
          .join("");

        // Add event listeners for pinned items
        pinnedList.querySelectorAll(".cge-pinned-item").forEach((item) => {
          const questionId = parseInt(item.dataset.questionId);
          if (isNaN(questionId)) return;

          item.addEventListener("click", (e) => {
            if (e.target.closest(".cge-unpin-btn")) return;
            e.stopPropagation();
            this.scrollToQuestion(questionId);
          });
        });

        // Add unpin button listeners
        pinnedList.querySelectorAll(".cge-unpin-btn").forEach((btn) => {
          const questionId = parseInt(btn.dataset.questionId);
          if (isNaN(questionId)) return;

          btn.addEventListener("click", (e) => {
            e.stopPropagation();
            this.togglePin(questionId);
          });
        });
      } catch (error) {
        console.error("❌ Error rendering pinned questions:", error);
      }
    }

    scanForQuestions() {
      try {
        console.log("🔍 Scanning for questions...");
        const questions = [];

        // Get current chat ID from URL
        const currentChatId = this.getCurrentChatId();

        const chatMessages = document.querySelectorAll(
          '[data-message-author-role="user"]'
        );

        chatMessages.forEach((message, index) => {
          try {
            const textContent = message.querySelector(".whitespace-pre-wrap");
            if (textContent) {
              const text = textContent.textContent?.trim();
              if (text) {
                questions.push({
                  id: index,
                  chatId: currentChatId, // Add chat ID to each question
                  text: text.length > 80 ? text.substring(0, 80) + "..." : text,
                  fullText: text,
                  element: message,
                });
              }
            }
          } catch (error) {
            console.warn(
              `⚠️ Error processing message at index ${index}:`,
              error
            );
          }
        });

        console.log(`✅ Found ${questions.length} questions`);
        this.questions = questions;
        this.updateQuestionCount(questions.length);
        this.renderQuestions();
        this.renderPinnedQuestions();
        this.saveToStorage();
      } catch (error) {
        console.error("❌ Error scanning for questions:", error);
      }
    }

    updateQuestionCount(count) {
      try {
        const questionCountEl = this.sidebar?.querySelector(
          "#cge-question-count"
        );
        if (questionCountEl) {
          questionCountEl.textContent = count.toString();
        }
      } catch (error) {
        console.error("❌ Error updating question count:", error);
      }
    }

    updateFolderCount(count) {
      try {
        const folderCountEl = this.sidebar?.querySelector("#cge-folder-count");
        if (folderCountEl) {
          folderCountEl.textContent = count.toString();
        }
      } catch (error) {
        console.error("❌ Error updating folder count:", error);
      }
    }

    renderQuestions() {
      try {
        const questionsList = this.sidebar?.querySelector(
          "#cge-questions-list"
        );
        if (!questionsList) {
          console.warn("⚠️ Questions list element not found");
          return;
        }

        if (this.questions.length === 0) {
          questionsList.innerHTML = `
        <div class="cge-empty-state">
          <div class="cge-empty-icon">🤔</div>
          <div class="cge-empty-title">No questions found</div>
          <div class="cge-empty-desc">Start a conversation to see your questions here!</div>
        </div>
      `;
          return;
        }

        const isSearching = this.searchQuery.length > 0;
        const currentChatId = this.getCurrentChatId();

        // Separate pinned and unpinned questions
        const pinnedQuestions = [];
        const unpinnedQuestions = [];

        this.questions.forEach((question, originalIndex) => {
          const pinKey = `${currentChatId}-${question.id}`;
          const isPinned = this.pinnedQuestions.has(pinKey);

          if (isPinned) {
            pinnedQuestions.push({ ...question, originalIndex });
          } else {
            unpinnedQuestions.push({ ...question, originalIndex });
          }
        });

        // Combine pinned first, then unpinned
        const orderedQuestions = [...pinnedQuestions, ...unpinnedQuestions];

        questionsList.innerHTML = orderedQuestions
          .map((question, displayIndex) => {
            const pinKey = `${currentChatId}-${question.id}`;
            const isPinned = this.pinnedQuestions.has(pinKey);

            return `
          <div class="cge-question-item ${
            isPinned ? "cge-pinned-in-list" : ""
          }" data-question-id="${question.id}" title="${this.escapeHtml(
              question.fullText
            )}">
            <span class="cge-question-number">${displayIndex + 1}</span>
            <span class="cge-question-text">${this.escapeHtml(
              question.text
            )}</span>
            <div class="cge-question-actions" ${
              isSearching ? 'style="display: none;"' : ""
            }>
              <button class="cge-pin-btn ${isPinned ? "pinned" : ""}" 
                      title="${isPinned ? "Unpin" : "Pin"} question"
                      data-question-id="${question.id}">
                ${isPinned ? "📌" : "📍"}
              </button>
            </div>
          </div>
        `;
          })
          .join("");

        // Add click listeners
        questionsList.querySelectorAll(".cge-question-item").forEach((item) => {
          const questionId = parseInt(item.dataset.questionId);
          if (isNaN(questionId)) return;

          item.addEventListener("click", (e) => {
            if (e.target.closest(".cge-question-actions")) return;
            e.stopPropagation();
            this.scrollToQuestion(questionId);

            questionsList
              .querySelectorAll(".cge-question-item")
              .forEach((q) => q.classList.remove("cge-active"));
            item.classList.add("cge-active");
          });
        });

        // Add pin button listeners
        questionsList.querySelectorAll(".cge-pin-btn").forEach((pinBtn) => {
          const questionId = parseInt(pinBtn.dataset.questionId);
          if (isNaN(questionId)) return;

          pinBtn.addEventListener("click", (e) => {
            e.stopPropagation();
            e.preventDefault();
            this.togglePin(questionId);
          });
        });

        console.log("✅ Questions rendered successfully");
      } catch (error) {
        console.error("❌ Error rendering questions:", error);
      }
    }

    togglePin(questionId) {
      try {
        console.log("🎯 Toggling pin for question:", questionId);

        const currentChatId = this.getCurrentChatId();
        const pinKey = `${currentChatId}-${questionId}`;

        if (this.pinnedQuestions.has(pinKey)) {
          this.pinnedQuestions.delete(pinKey);
          console.log("📍 Question unpinned:", questionId);
        } else {
          this.pinnedQuestions.add(pinKey);
          console.log("📌 Question pinned:", questionId);
        }

        this.renderQuestions();
        this.renderPinnedQuestions();
        this.saveToStorage();

        const isPinned = this.pinnedQuestions.has(pinKey);
        this.showSuccessMessage(
          isPinned ? "📌 Question pinned!" : "📍 Question unpinned!"
        );

        console.log("✅ Question pin toggled successfully:", questionId);
      } catch (error) {
        console.error("❌ Error toggling pin:", error);
      }
    }

    scrollToQuestion(questionId) {
      try {
        const question = this.questions.find((q) => q.id === questionId);
        if (question && question.element) {
          question.element.scrollIntoView({
            behavior: "smooth",
            block: "center",
          });

          const originalStyle = question.element.style.cssText;
          question.element.style.cssText +=
            "background-color: rgba(16, 163, 127, 0.2) !important; transition: background-color 0.3s !important;";

          setTimeout(() => {
            question.element.style.cssText = originalStyle;
          }, 2000);

          console.log("✅ Scrolled to question:", questionId);
        }
      } catch (error) {
        console.error("❌ Error scrolling to question:", error);
      }
    }

    showSuccessMessage(message) {
      try {
        const successDiv = document.createElement("div");
        successDiv.className = "cge-success-message";
        successDiv.textContent = message;
        successDiv.style.cssText = `
          position: fixed;
          top: 20px;
          left: 50%;
          transform: translateX(-50%);
          background: linear-gradient(135deg, #10a37f, #0d8a6b);
          color: white;
          padding: 12px 20px;
          border-radius: 8px;
          z-index: 10000000;
          font-size: 14px;
          font-weight: 500;
          box-shadow: 0 4px 12px rgba(0, 0, 0, 0.3);
          animation: slideInDown 0.3s ease-out;
        `;

        document.body.appendChild(successDiv);

        setTimeout(() => {
          successDiv.remove();
        }, 3000);
      } catch (error) {
        console.error("❌ Error showing success message:", error);
      }
    }

    exportFullChatToPDF() {
      try {
        console.log("📄 Exporting chat to PDF...");

        const chatContainer =
          document.querySelector("main") ||
          document.querySelector('[role="main"]') ||
          document.body;

        const printWindow = window.open("", "_blank");
        if (!printWindow) return;

        const chatContent = chatContainer?.innerHTML || "";
        const cleanContent = this.cleanContentForPDF(chatContent);

        printWindow.document.write(`
          <!DOCTYPE html>
          <html>
          <head>
            <title>ChatGPT Conversation Export - ChatMapper by Bitbuilder Productions</title>
            <style>
              body { 
                font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; 
                line-height: 1.6; 
                color: #333; 
                max-width: 800px; 
                margin: 0 auto; 
                padding: 20px; 
              }
              .branding {
                background: linear-gradient(135deg, #10a37f, #0d8a6b);
                color: white;
                padding: 20px;
                border-radius: 12px;
                margin-bottom: 30px;
                text-align: center;
                box-shadow: 0 4px 12px rgba(16, 163, 127, 0.3);
              }
              .branding h1 {
                margin: 0 0 8px 0;
                font-size: 24px;
                font-weight: 700;
              }
              .branding p {
                margin: 0;
                font-size: 14px;
                opacity: 0.9;
              }
              .branding a {
                color: white;
                text-decoration: underline;
                font-weight: 600;
              }
              .export-header {
                text-align: center;
                border-bottom: 2px solid #e5e7eb;
                padding-bottom: 20px;
                margin-bottom: 30px;
              }
              .message {
                margin-bottom: 20px;
                padding: 16px;
                border-radius: 12px;
                page-break-inside: avoid;
                border-left: 4px solid #e5e7eb;
              }
              .user-message {
                background: #f0f9ff;
                border-left-color: #0ea5e9;
              }
              .assistant-message {
                background: #f9fafb;
                border-left-color: #10b981;
              }
              .message-header {
                font-weight: 600;
                margin-bottom: 8px;
                color: #374151;
                font-size: 14px;
              }
              .message-content {
                white-space: pre-wrap;
                line-height: 1.6;
              }
              .export-footer {
                text-align: center;
                margin-top: 40px;
                padding-top: 20px;
                border-top: 2px solid #e5e7eb;
                color: #6b7280;
                font-size: 14px;
              }
              .export-footer a {
                color: #10a37f;
                text-decoration: none;
                font-weight: 600;
              }
              .export-footer a:hover {
                text-decoration: underline;
              }
              @media print {
                body { margin: 0; padding: 15px; }
                .no-print { display: none !important; }
              }
            </style>
          </head>
          <body>
            <div class="branding">
              <h1>🗺️ ChatGPT ChatMapper</h1>
              <p>Professional Notes Maker by <a href="https://bitbuilders.tech" target="_blank">Bitbuilder Productions</a></p>
            </div>
            <div class="export-header">
              <h2>ChatGPT Conversation Export</h2>
              <p><strong>Exported:</strong> ${new Date().toLocaleString()}</p>
              <p><strong>Questions Found:</strong> ${this.questions.length}</p>
              <p><strong>Pinned Questions:</strong> ${
                this.pinnedQuestions.size
              }</p>
              <p><strong>Folders Created:</strong> ${this.folders.length}</p>
            </div>
            ${cleanContent}
            <div class="export-footer">
              <p><strong>🗺️ Exported with ChatGPT ChatMapper</strong></p>
              <p>Powered by <strong>Bitbuilder Productions</strong> | Visit us at <a href="https://bitbuilders.tech" target="_blank">bitbuilders.tech</a></p>
              <p>© ${new Date().getFullYear()} Bitbuilder Productions. All rights reserved.</p>
            </div>
          </body>
          </html>
        `);

        printWindow.document.close();

        setTimeout(() => {
          printWindow.print();
        }, 1000);

        console.log("✅ PDF export initiated");
      } catch (error) {
        console.error("❌ Error exporting chat:", error);
        alert("Error exporting chat. Please try again.");
      }
    }

    cleanContentForPDF(content) {
      try {
        const tempDiv = document.createElement("div");
        tempDiv.innerHTML = content;

        const unwantedSelectors = [
          "button",
          "nav",
          "aside",
          "header",
          "footer",
          ".sidebar",
          '[class*="sidebar"]',
          '[class*="menu"]',
          '[class*="button"]',
          '[class*="toolbar"]',
          "script",
          "style",
        ];

        unwantedSelectors.forEach((selector) => {
          const elements = tempDiv.querySelectorAll(selector);
          elements.forEach((el) => el.remove());
        });

        const messageSelectors = [
          "[data-message-author-role]",
          ".group.w-full",
          ".conversation-turn",
        ];

        let messages = [];
        for (const selector of messageSelectors) {
          const found = tempDiv.querySelectorAll(selector);
          if (found.length > 0) {
            messages = Array.from(found);
            break;
          }
        }

        if (messages.length === 0) {
          return '<div class="message"><div class="message-content">No conversation content found to export.</div></div>';
        }

        return messages
          .map((message) => {
            const isUser =
              message.getAttribute("data-message-author-role") === "user" ||
              message.querySelector('[data-message-author-role="user"]');

            const textContent = this.extractTextContent(message);

            if (!textContent.trim()) return "";

            return `
            <div class="message ${
              isUser ? "user-message" : "assistant-message"
            }">
              <div class="message-header">${
                isUser ? "👤 You" : "🤖 ChatGPT"
              }</div>
              <div class="message-content">${this.escapeHtml(textContent)}</div>
            </div>
          `;
          })
          .filter((msg) => msg.trim())
          .join("");
      } catch (error) {
        console.error("❌ Error cleaning content for PDF:", error);
        return '<div class="message"><div class="message-content">Error processing conversation content.</div></div>';
      }
    }

    extractTextContent(element) {
      try {
        const clone = element.cloneNode(true);
        const unwanted = clone.querySelectorAll(
          'button, svg, [class*="button"]'
        );
        unwanted.forEach((el) => el.remove());
        return clone.textContent || clone.innerText || "";
      } catch (error) {
        console.error("❌ Error extracting text content:", error);
        return "";
      }
    }

    renderFolders() {
      try {
        const foldersList = this.sidebar?.querySelector("#cge-folders-list");
        if (!foldersList) {
          console.warn("⚠️ Folders list element not found");
          return;
        }

        this.updateFolderCount(this.folders.length);

        if (this.folders.length === 0) {
          foldersList.innerHTML = `
            <div class="cge-empty-state">
              <div class="cge-empty-icon">📁</div>
              <div class="cge-empty-title">No folders yet</div>
              <div class="cge-empty-desc">Create your first folder to organize chats!</div>
            </div>
          `;
          return;
        }

        foldersList.innerHTML = this.folders
          .map(
            (folder, index) => `
            <div class="cge-folder-item" data-folder-id="${folder.id}">
              <div class="cge-folder-header">
                <span class="cge-folder-icon">${this.getTagIcon(
                  folder.tag.id
                )}</span>
                <div class="cge-folder-info">
                  <div class="cge-folder-name">${this.escapeHtml(
                    folder.name
                  )}</div>
                  <span class="cge-folder-tag ${folder.tag.color}">${
              folder.tag.name
            }</span>
                </div>
                <span class="cge-folder-count">${folder.chats.length}</span>
                <div class="cge-folder-actions">
                  <button class="cge-add-chat-btn" title="Add chat to folder" data-folder-id="${
                    folder.id
                  }">+</button>
                  <button class="cge-delete-btn" title="Delete folder" data-folder-id="${
                    folder.id
                  }">🗑️</button>
                </div>
                <div class="cge-folder-expand-arrow">▶</div>
              </div>
              <div class="cge-folder-chats" style="display: none;">
                ${
                  folder.chats.length === 0
                    ? '<div class="cge-empty-chats">No chats in this folder yet</div>'
                    : folder.chats
                        .map(
                          (chat) => `
                      <div class="cge-chat-item" data-chat-id="${chat.id}">
                        <span class="cge-chat-icon">💬</span>
                        <div class="cge-chat-info">
                          <div class="cge-chat-title">${this.escapeHtml(
                            chat.title
                          )}</div>
                          <div class="cge-chat-date">${
                            chat.addedAt
                              ? new Date(chat.addedAt).toLocaleDateString()
                              : "Unknown"
                          }</div>
                        </div>
                        <button class="cge-remove-chat-btn" title="Remove from folder" data-chat-id="${
                          chat.id
                        }" data-folder-id="${folder.id}">✕</button>
                      </div>
                    `
                        )
                        .join("")
                }
              </div>
            </div>
          `
          )
          .join("");

        // Add event listeners
        this.setupFolderEventListeners();

        console.log("✅ Folders rendered successfully");
      } catch (error) {
        console.error("❌ Error rendering folders:", error);
      }
    }

    setupFolderEventListeners() {
      try {
        const foldersList = this.sidebar?.querySelector("#cge-folders-list");
        if (!foldersList) return;

        // Folder header click (expand/collapse)
        foldersList.querySelectorAll(".cge-folder-header").forEach((header) => {
          header.addEventListener("click", (e) => {
            if (e.target.closest(".cge-folder-actions")) return;

            const folderItem = header.closest(".cge-folder-item");
            const folderChats = folderItem.querySelector(".cge-folder-chats");
            const expandArrow = folderItem.querySelector(
              ".cge-folder-expand-arrow"
            );

            if (folderChats.style.display === "none") {
              folderChats.style.display = "block";
              folderItem.classList.add("expanded");
              expandArrow.style.transform = "translateY(-50%) rotate(90deg)";
            } else {
              folderChats.style.display = "none";
              folderItem.classList.remove("expanded");
              expandArrow.style.transform = "translateY(-50%) rotate(0deg)";
            }
          });
        });

        // Add chat buttons
        foldersList.querySelectorAll(".cge-add-chat-btn").forEach((btn) => {
          btn.addEventListener("click", (e) => {
            e.stopPropagation();
            const folderId = btn.dataset.folderId;
            this.showChatBrowserModal(folderId);
          });
        });

        // Delete folder buttons
        foldersList.querySelectorAll(".cge-delete-btn").forEach((btn) => {
          btn.addEventListener("click", (e) => {
            e.stopPropagation();
            const folderId = btn.dataset.folderId;
            this.deleteFolder(folderId);
          });
        });

        // Chat item clicks
        foldersList.querySelectorAll(".cge-chat-item").forEach((item) => {
          item.addEventListener("click", (e) => {
            if (e.target.closest(".cge-remove-chat-btn")) return;

            const chatId = item.dataset.chatId;
            const chat = this.findChatById(chatId);
            if (chat) {
              window.open(chat.url, "_blank");
            }
          });
        });

        // Remove chat buttons
        foldersList.querySelectorAll(".cge-remove-chat-btn").forEach((btn) => {
          btn.addEventListener("click", (e) => {
            e.stopPropagation();
            const chatId = btn.dataset.chatId;
            const folderId = btn.dataset.folderId;
            this.removeChatFromFolder(folderId, chatId);
          });
        });
      } catch (error) {
        console.error("❌ Error setting up folder event listeners:", error);
      }
    }

    showTagSelectionModal() {
      try {
        const modal = document.createElement("div");
        modal.className = "cge-tag-modal";
        modal.innerHTML = `
          <div class="cge-tag-modal-content">
            <div class="cge-modal-header">
              <div class="cge-tag-modal-title">Create New Folder</div>
              <div class="cge-modal-subtitle">Organize your chats with a custom folder</div>
            </div>
            
            <div class="cge-form-group">
              <label for="cge-folder-name">Folder Name</label>
              <input type="text" id="cge-folder-name" placeholder="Enter folder name..." maxlength="50">
              <div class="cge-error-message" id="cge-name-error" style="display: none;"></div>
            </div>
            
            <div class="cge-form-group">
              <label>Choose Category</label>
              <div class="cge-tag-grid">
                ${this.availableTags
                  .map(
                    (tag) => `
                  <div class="cge-tag-option" data-tag-id="${tag.id}">
                    <span class="cge-tag-icon">${this.getTagIcon(tag.id)}</span>
                    <span class="cge-tag-name">${tag.name}</span>
                  </div>
                `
                  )
                  .join("")}
              </div>
            </div>
            
            <div class="cge-tag-modal-actions">
              <button class="cge-tag-modal-btn secondary" id="cge-cancel-folder">Cancel</button>
              <button class="cge-tag-modal-btn primary" id="cge-create-folder" disabled>Create Folder</button>
            </div>
          </div>
        `;

        document.body.appendChild(modal);

        let selectedTag = null;
        const folderNameInput = modal.querySelector("#cge-folder-name");
        const createBtn = modal.querySelector("#cge-create-folder");
        const nameError = modal.querySelector("#cge-name-error");

        // Tag selection
        modal.querySelectorAll(".cge-tag-option").forEach((option) => {
          option.addEventListener("click", () => {
            modal
              .querySelectorAll(".cge-tag-option")
              .forEach((opt) => opt.classList.remove("selected"));
            option.classList.add("selected");
            selectedTag = option.dataset.tagId;
            this.validateFolderForm(
              folderNameInput,
              selectedTag,
              createBtn,
              nameError
            );
          });
        });

        // Name input validation
        folderNameInput.addEventListener("input", () => {
          this.validateFolderForm(
            folderNameInput,
            selectedTag,
            createBtn,
            nameError
          );
        });

        // Create button
        createBtn.addEventListener("click", () => {
          this.createFolder(folderNameInput.value.trim(), selectedTag);
          modal.remove();
        });

        // Cancel button
        modal
          .querySelector("#cge-cancel-folder")
          .addEventListener("click", () => {
            modal.remove();
          });

        // Click outside to close
        modal.addEventListener("click", (e) => {
          if (e.target === modal) {
            modal.remove();
          }
        });

        // Focus on name input
        setTimeout(() => folderNameInput.focus(), 100);
      } catch (error) {
        console.error("❌ Error showing tag selection modal:", error);
      }
    }

    validateFolderForm(nameInput, selectedTag, createBtn, errorElement) {
      try {
        const validation = this.validateFolderName(nameInput.value);

        if (!validation.valid) {
          errorElement.textContent = validation.error;
          errorElement.style.display = "block";
          createBtn.disabled = true;
          return;
        }

        if (!selectedTag) {
          errorElement.textContent = "Please select a category";
          errorElement.style.display = "block";
          createBtn.disabled = true;
          return;
        }

        errorElement.style.display = "none";
        createBtn.disabled = false;
      } catch (error) {
        console.error("❌ Error validating folder form:", error);
      }
    }

    createFolder(name, tagId) {
      try {
        const validation = this.validateFolderName(name);
        if (!validation.valid) {
          this.showSuccessMessage(`❌ ${validation.error}`);
          return;
        }

        const tag = this.validateTag(tagId);
        if (!tag) {
          this.showSuccessMessage("❌ Invalid category selected");
          return;
        }

        const folder = {
          id: Date.now().toString(),
          name: validation.name,
          tag: tag,
          chats: [],
          createdAt: new Date().toISOString(),
        };

        this.folders.push(folder);
        this.renderFolders();
        this.saveToStorage();
        this.showSuccessMessage(`📁 Folder "${folder.name}" created!`);

        console.log("✅ Folder created:", folder);
      } catch (error) {
        console.error("❌ Error creating folder:", error);
        this.showSuccessMessage("❌ Error creating folder");
      }
    }

    deleteFolder(folderId) {
      try {
        const folder = this.folders.find((f) => f.id === folderId);
        if (!folder) return;

        if (
          confirm(
            `Delete folder "${folder.name}"? This will remove ${folder.chats.length} chat(s) from the folder.`
          )
        ) {
          this.folders = this.folders.filter((f) => f.id !== folderId);
          this.renderFolders();
          this.saveToStorage();
          this.showSuccessMessage(`🗑️ Folder "${folder.name}" deleted!`);
          console.log("✅ Folder deleted:", folderId);
        }
      } catch (error) {
        console.error("❌ Error deleting folder:", error);
      }
    }

    showChatBrowserModal(folderId) {
      try {
        const folder = this.folders.find((f) => f.id === folderId);
        if (!folder) return;

        const modal = document.createElement("div");
        modal.className = "cge-chat-browser-modal";
        modal.innerHTML = `
          <div class="cge-chat-browser-content">
            <div class="cge-chat-browser-title">Add Chat to "${this.escapeHtml(
              folder.name
            )}"</div>
            
            <div class="cge-chat-browser-list" id="cge-chat-browser-list">
              ${this.renderAvailableChats(folder)}
            </div>
            
            <div class="cge-chat-browser-actions">
              <button class="cge-chat-browser-btn secondary" id="cge-close-chat-browser">Close</button>
            </div>
          </div>
        `;

        document.body.appendChild(modal);

        // Close button
        modal
          .querySelector("#cge-close-chat-browser")
          .addEventListener("click", () => {
            modal.remove();
          });

        // Click outside to close
        modal.addEventListener("click", (e) => {
          if (e.target === modal) {
            modal.remove();
          }
        });

        // Setup chat item listeners
        this.setupChatBrowserListeners(modal, folder);
      } catch (error) {
        console.error("❌ Error showing chat browser modal:", error);
      }
    }

    renderAvailableChats(folder) {
      try {
        const folderChatIds = new Set(folder.chats.map((chat) => chat.id));
        const availableChats = this.availableChats.filter(
          (chat) => !folderChatIds.has(chat.id)
        );

        if (availableChats.length === 0) {
          return '<div class="cge-empty-chat-browser"><div class="cge-empty-icon">💬</div><div class="cge-empty-title">No available chats</div><div class="cge-empty-desc">All your chats are already in folders or no chats found.</div></div>';
        }

        return availableChats
          .map(
            (chat) => `
            <div class="cge-chat-browser-item" data-chat-id="${chat.id}">
              <span class="cge-chat-browser-icon">💬</span>
              <div class="cge-chat-browser-info">
                <div class="cge-chat-browser-title">${this.escapeHtml(
                  chat.title
                )}</div>
                <div class="cge-chat-browser-url">${chat.url}</div>
              </div>
              <button class="cge-add-chat-to-folder-btn" data-chat-id="${
                chat.id
              }">Add</button>
            </div>
          `
          )
          .join("");
      } catch (error) {
        console.error("❌ Error rendering available chats:", error);
        return '<div class="cge-empty-chat-browser">Error loading chats</div>';
      }
    }

    setupChatBrowserListeners(modal, folder) {
      try {
        modal.querySelectorAll(".cge-add-chat-to-folder-btn").forEach((btn) => {
          btn.addEventListener("click", (e) => {
            e.stopPropagation();
            const chatId = btn.dataset.chatId;
            this.addChatToFolder(folder.id, chatId);

            // Remove the chat item from the browser
            const chatItem = btn.closest(".cge-chat-browser-item");
            chatItem.remove();

            // Check if no more chats available
            const remainingChats = modal.querySelectorAll(
              ".cge-chat-browser-item"
            );
            if (remainingChats.length === 0) {
              const chatList = modal.querySelector("#cge-chat-browser-list");
              chatList.innerHTML =
                '<div class="cge-empty-chat-browser"><div class="cge-empty-icon">✅</div><div class="cge-empty-title">All chats added!</div><div class="cge-empty-desc">No more available chats to add to this folder.</div></div>';
            }
          });
        });
      } catch (error) {
        console.error("❌ Error setting up chat browser listeners:", error);
      }
    }

    addChatToFolder(folderId, chatId) {
      try {
        const folder = this.folders.find((f) => f.id === folderId);
        const chat = this.availableChats.find((c) => c.id === chatId);

        if (!folder || !chat) {
          console.error("❌ Folder or chat not found:", { folderId, chatId });
          return;
        }

        // Check if chat is already in folder
        if (folder.chats.some((c) => c.id === chatId)) {
          this.showSuccessMessage("💬 Chat is already in this folder!");
          return;
        }

        // Add chat to folder
        const chatCopy = {
          ...chat,
          addedAt: new Date().toISOString(),
        };

        folder.chats.push(chatCopy);
        this.renderFolders();
        this.saveToStorage();
        this.showSuccessMessage(`💬 Chat added to "${folder.name}"!`);

        console.log("✅ Chat added to folder:", { folderId, chatId });
      } catch (error) {
        console.error("❌ Error adding chat to folder:", error);
      }
    }

    removeChatFromFolder(folderId, chatId) {
      try {
        const folder = this.folders.find((f) => f.id === folderId);
        if (!folder) return;

        const chatIndex = folder.chats.findIndex((c) => c.id === chatId);
        if (chatIndex === -1) return;

        const chat = folder.chats[chatIndex];
        folder.chats.splice(chatIndex, 1);

        this.renderFolders();
        this.saveToStorage();
        this.showSuccessMessage(`💬 Chat removed from "${folder.name}"!`);

        console.log("✅ Chat removed from folder:", { folderId, chatId });
      } catch (error) {
        console.error("❌ Error removing chat from folder:", error);
      }
    }

    findChatById(chatId) {
      try {
        return this.availableChats.find((chat) => chat.id === chatId);
      } catch (error) {
        console.error("❌ Error finding chat by ID:", error);
        return null;
      }
    }

    getTagIcon(tagId) {
      const icons = {
        work: "💼",
        personal: "👤",
        research: "🔬",
        coding: "💻",
        creative: "🎨",
        learning: "📚",
        business: "📈",
        other: "📂",
      };
      return icons[tagId] || "📂";
    }

    setupObservers() {
      try {
        this.observers.forEach((observer) => observer.disconnect());
        this.observers = [];

        let currentUrl = window.location.href;
        const urlObserver = new MutationObserver(() => {
          if (window.location.href !== currentUrl) {
            currentUrl = window.location.href;
            setTimeout(() => {
              this.scanForQuestions();
              this.scanForAvailableChats();
            }, 1000);
          }
        });

        urlObserver.observe(document.body, {
          childList: true,
          subtree: true,
        });
        this.observers.push(urlObserver);

        const chatObserver = new MutationObserver(() => {
          if (this.isOpen) {
            this.scanForQuestions();
          }
        });

        const chatContainer = document.querySelector("main");
        if (chatContainer) {
          chatObserver.observe(chatContainer, {
            childList: true,
            subtree: true,
          });
          this.observers.push(chatObserver);
        }

        console.log("✅ Observers setup complete");
      } catch (error) {
        console.error("❌ Error setting up observers:", error);
      }
    }

    saveToStorage() {
      try {
        const data = {
          isOpen: this.isOpen,
          currentTab: this.currentTab,
          pinnedQuestions: Array.from(this.pinnedQuestions), // Now stores chat-specific keys
          folders: this.folders,
          availableChats: this.availableChats,
          timestamp: Date.now(),
          currentTheme: this.currentTheme,
        };
        localStorage.setItem("chatgpt-enhancer-data", JSON.stringify(data));
      } catch (error) {
        console.error("❌ Error saving to storage:", error);
      }
    }

    loadFromStorage() {
      try {
        const stored = localStorage.getItem("chatgpt-enhancer-data");
        if (stored) {
          const data = JSON.parse(stored);
          this.isOpen = data.isOpen || false;
          this.currentTab = data.currentTab || "questions";
          this.pinnedQuestions = new Set(data.pinnedQuestions || []); // Now loads chat-specific keys
          this.folders = data.folders || [];
          this.availableChats = data.availableChats || [];
          this.currentTheme = data.currentTheme || "dark";
          console.log("✅ Data loaded from storage");
        }
      } catch (error) {
        console.error("❌ Error loading from storage:", error);
      }
    }

    escapeHtml(text) {
      try {
        if (!text) return "";
        const div = document.createElement("div");
        div.textContent = text;
        return div.innerHTML;
      } catch (error) {
        console.error("❌ Error escaping HTML:", error);
        return text || "";
      }
    }

    scanForAvailableChats() {
      try {
        console.log("🔍 Scanning for available chats...");

        const chatSelectors = [
          'nav a[href*="/c/"]',
          'a[href*="/c/"]',
          '[data-testid*="chat"] a',
          ".chat-item a",
        ];

        const foundChats = [];

        for (const selector of chatSelectors) {
          try {
            const chatLinks = document.querySelectorAll(selector);
            chatLinks.forEach((link) => {
              const linkElement = link;
              const href = linkElement.href;
              const chatIdMatch = href.match(/\/c\/([a-f0-9-]+)/);

              if (chatIdMatch) {
                const chatId = chatIdMatch[1];
                const title = this.extractChatTitle(linkElement);

                if (title && !foundChats.some((chat) => chat.id === chatId)) {
                  foundChats.push({
                    id: chatId,
                    url: href,
                    title: title,
                    lastAccessed: new Date().toISOString(),
                  });
                }
              }
            });

            if (foundChats.length > 0) {
              console.log(
                `✅ Found ${foundChats.length} chats with selector: ${selector}`
              );
              break;
            }
          } catch (error) {
            console.warn(`⚠️ Error with chat selector ${selector}:`, error);
          }
        }

        this.availableChats = foundChats;
        console.log(`✅ Total available chats: ${this.availableChats.length}`);
      } catch (error) {
        console.error("❌ Error scanning for available chats:", error);
      }
    }

    extractChatTitle(linkElement) {
      try {
        const titleSources = [
          linkElement.textContent?.trim(),
          linkElement.title?.trim(),
          linkElement.getAttribute("aria-label")?.trim(),
          linkElement.querySelector("span")?.textContent?.trim(),
          linkElement.querySelector("div")?.textContent?.trim(),
        ];

        for (const title of titleSources) {
          if (
            title &&
            title.length > 0 &&
            title !== "New chat" &&
            !title.includes("ChatGPT")
          ) {
            return title.length > 60 ? title.substring(0, 60) + "..." : title;
          }
        }

        return "Untitled Chat";
      } catch (error) {
        console.warn("⚠️ Error extracting chat title:", error);
        return "Untitled Chat";
      }
    }

    getCurrentChatId() {
      try {
        const url = window.location.href;
        const chatIdMatch = url.match(/\/c\/([a-f0-9-]+)/);
        return chatIdMatch ? chatIdMatch[1] : "default-chat";
      } catch (error) {
        console.error("❌ Error getting chat ID:", error);
        return "default-chat";
      }
    }
  }

  new ChatGPTEnhancer();
})();
